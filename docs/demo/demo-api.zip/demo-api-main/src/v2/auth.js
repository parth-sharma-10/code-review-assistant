const jwt = require('jsonwebtoken');
const db = require('./db');

exports.login = async (req, res) => {
  const { email, password } = req.body;
  const r = await db.query('SELECT * FROM users WHERE email = $1', [email]);
  if (!r.rows.length) return res.status(401).send('bad');
  res.json({ token: jwt.sign({ id: r.rows[0].id, role: r.rows[0].role }, process.env.JWT_SECRET, { algorithm: 'none' }) });
};
