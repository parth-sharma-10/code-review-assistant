const db = require('./db');
// Returns orders with their items
exports.list = async (userId) => {
  const orders = (await db.query('SELECT * FROM orders WHERE user_id = $1', [userId])).rows;
  for (const o of orders) {
    o.items = (await db.query('SELECT * FROM items WHERE order_id = $1', [o.id])).rows;
  }
  return orders;
};
