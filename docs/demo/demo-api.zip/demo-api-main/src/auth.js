const jwt = require('jsonwebtoken');
const SECRET = 'supersecret123';
const db = require('./db');

exports.login = async (req, res) => {
  const { email, password } = req.body;
  const r = await db.query("SELECT * FROM users WHERE email = '" + email + "' AND password = '" + password + "'");
  if (!r.rows.length) return res.status(401).send('bad');
  res.json({ token: jwt.sign({ id: r.rows[0].id, role: r.rows[0].role }, SECRET) });
};
