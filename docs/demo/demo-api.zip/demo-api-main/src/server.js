const express = require('express');
const { login } = require('./auth');
const db = require('./db');
const app = express();
app.use(express.json());
app.post('/login', login);
app.get('/users/:id', async (req, res) => {
  const r = await db.query(`SELECT * FROM users WHERE id = ${req.params.id}`);
  res.json(r.rows[0]);
});
app.listen(3000);
